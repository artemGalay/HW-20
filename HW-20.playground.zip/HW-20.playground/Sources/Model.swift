import Foundation

struct Cards: Decodable {
    let name: String?
    let manaCost: String?
    let cmc: Double?
    var colors: [String]? = []
    var colorIdentity: [String]? = []
    let type: String?
    var types: [String]? = []
    var subtypes: [String]? = []
    let rarity: String?
    let set: String?
}
