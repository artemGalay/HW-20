import Foundation

struct Initial: Decodable {
    let cards: [Card]
}

struct Card: Decodable {
    let name: String?
    let cmc: Int?
    let manaCost: String?
    let setName: String?
    let flavor: String?
    let artist: String?
    let number: String?
}

func getData(urlRequest: String) {
    let urlRequest = URL(string: urlRequest)
    let configuration = URLSessionConfiguration.default
    configuration.allowsCellularAccess = true // когда отключён Wi-Fi
    guard let url = urlRequest else { return }
    URLSession.shared.dataTask(with: url) { (data, response, error) in
        if let error = error {
            print("error: \(error.localizedDescription)")
        } else {
            if let response = response as? HTTPURLResponse, response.statusCode == 200 {
                print("statusCode: \(response.statusCode)")
            }
            guard let data = data else { return }
            do {
                let result = try JSONDecoder().decode(Initial.self, from: data)
                print("""
                      Имя карты: \(result.cards.first?.name ?? "")
                      Cmc: \(result.cards.first?.cmc ?? 0)
                      ManaCost: \(result.cards.first?.manaCost ?? "")
                      SetName: \(result.cards.first?.setName ?? "")
                      Flavor: \(result.cards.first?.flavor ?? "")
                      Artist: \(result.cards.first?.flavor ?? "")
                      Number: \(result.cards.first?.number ?? "")
                      """)
            } catch {
                print(error)
            }
        }
    }.resume()
}

var urlOpt = "https://api.magicthegathering.io/v1/cards?name=%22Opt%22"
var urlBlackLotus = "https://api.magicthegathering.io/v1/cards?name=%22Black%20Lotus%22"

getData(urlRequest: urlOpt)
getData(urlRequest: urlBlackLotus)
